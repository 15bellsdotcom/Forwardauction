<?php
/**
 * @var $this yii\web\View
 */
?>
<?php $this->beginContent('@backend/modules/transaction/views/layouts/moderator_layout.php'); ?>
    <div class="box">
        <div class="box-body">
            <?php echo $content ?>
        </div>
    </div>
<?php $this->endContent(); ?>