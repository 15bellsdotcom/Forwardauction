<div class="container-fluid" style="background-color:rgba(255, 140, 140, 0.99);">
                    <!-- Brand and toggle get grouped for better mobile display -->
                 <center><i><b>  <i class="fa fa-warning"> This Site is under Beta Testing Stage .</i></b></i></center>

                </div>